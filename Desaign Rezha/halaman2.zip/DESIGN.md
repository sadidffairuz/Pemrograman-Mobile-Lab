---
name: Kinetic Solitude
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#0058be'
  on-secondary: '#ffffff'
  secondary-container: '#2170e4'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#0b1c30'
  on-tertiary-container: '#75859d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-hero:
    fontFamily: Inter
    fontSize: 44px
    fontWeight: '600'
    lineHeight: 52px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  meta-mono:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 4rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

The design system embodies modern editorial minimalism tailored for the deliberate, observant traveler. Rather than overwhelming the user with travel cliches, vivid souvenir palettes, or skeuomorphic leather journals, it operates like an architectural field notebook or a quiet, Swiss-designed monograph. The visual tone is introspective, refined, and frictionless—giving precedence entirely to prose, temporal metadata, and high-fidelity photography.

Key brand pillars:
- **Atmospheric Restraint:** White space functions as breathing room. Negative space separates thoughts rather than heavy chromatic divisions.
- **Editorial Directness:** High-contrast neutral typography provides immediate clarity and an aura of published print literature.
- **Precision Engineering:** Monoline dividers, microscopic metadata badges, and exact typographic alignments replace decorative flair.

Visual language leans strictly on high-end minimalism mixed with modern editorial design: pure white content planes, hairline borders, deliberate typography scales, and a muted, deep slate indigo accent applied with extreme discipline.

## Colors

The palette is rooted in an ultra-clean, clinical-yet-warm neutral spectrum that eliminates visual fatigue while maintaining uncompromising legibility.

- **Primary (`#0F172A` - Slate 900):** Deep charcoal ink used for primary body copy, bold display titles, and high-priority interface anchors. Replaces harsh `#000000` with an authentic, obsidian-ink density.
- **Secondary (`#3B82F6` - Slate Indigo / Cobalt Tint):** A controlled, intellectual blue deployed sparingly for active states, timeline links, and specific semantic points of interest. It is never used in expansive floods or decorative fills.
- **Tertiary (`#64748B` - Slate 500):** Subdued stone slate for temporal indicators, GPS coordinates, camera metadata (ISO, aperture), and secondary captions.
- **Neutral Canvas (`#F8FAFC` - Slate 50):** The primary backdrop behind the content layer, providing a faint, calming contrast against pure white cards (`#FFFFFF`).
- **Dividers & Hairlines (`#E2E8F0` - Slate 200):** Exact 1px borders providing architectural containment without blocking natural eye scanning.

## Typography

The typographical voice utilizes `Inter` as a singular grotesque workhorse, relying on precise optical weight hierarchies, tight negative tracking on larger scales, and generous leading for long-form narrative journal passages. 

- **Tracking Rules:** As sizes scale above 20px, apply negative tracking (ranging from `-0.015em` to `-0.03em`) to mimic contemporary publication titles. For microscopic UI labels and timestamps, apply slight positive tracking (`0.02em` to `0.04em`) to safeguard character definition.
- **Narrative Entries:** Long-form journal entries rely on `body-lg` (18px/28px) with a strict line length constraint capped between 60 to 75 characters per line to emulate book typography.
- **Metadata Accent:** `JetBrains Mono` handles coordinates, altitude, elevation, weather parameters, and shutter/aperture logs, creating a deliberate visual tension between poetic prose and scientific recording.

## Layout & Spacing

The layout is governed by an unyielding 16dp / 1rem baseline rhythm. Components, card contents, and structural margins align directly to multiples of 4px and 16px.

- **Breakpoints & Grids:**
  - **Mobile (< 768px):** Single column stream; fixed 16px outer margins (`margin`); 16px vertical gap between journal log cards.
  - **Tablet (768px - 1024px):** 6-column fluid structure; 32px canvas margins (`margin-tablet`); 16px gutters (`gutter`). Supports a split-screen view: daily timeline index on the left (2 columns), expanded reading pane on the right (4 columns).
  - **Desktop (> 1024px):** Centered fixed-width viewport (maximum 1120px) to prevent disorienting card stretching, framed by 64px auto-margins (`margin-desktop`) and 24px column gutters (`gutter-desktop`).
- **Rhythm Discipline:** Component internal padding uses strictly `space-md` (16px) or `space-lg` (24px). Micro-elements (such as chips or metadata pills) lock strictly to 4px (`space-2xs`) vertical and 8px-12px (`space-xs`-`space-sm`) horizontal steps.

## Elevation & Depth

This system intentionally rejects skeuomorphic drop shadows, heavy blur dispersions, and stacked z-index projections. Depth is rendered completely flat through tactile surface delineation and 1px hairline structural frames.

- **Surface Tiers:**
  - **Level 0 (Canvas):** `#F8FAFC` base application background.
  - **Level 1 (Card & Content Surface):** `#FFFFFF` pure white surfaces.
  - **Level 2 (Overlays & Modals):** `#FFFFFF` paired with an immediate, high-definition 1px boundary (`#CBD5E1`) and a soft, non-directional shadow (`0px 8px 30px rgba(15, 23, 42, 0.05)`).
- **The Hairline Divider Rule:** Every card, cell, and list division is separated by a 1px solid border using `#E2E8F0`. When cards sit on the `#F8FAFC` background, the border crispness replaces the need for elevation blur.
- **Focus & States:** Interactive cards never scale up or cast floating shadows on hover; instead, their border color transitions crisply from `#E2E8F0` to `#94A3B8`, signaling tangible responsiveness without visual noise.

## Shapes

The design system enforces a disciplined `roundedness: 1` scale, mapped precisely to 12dp / 0.75rem (`rounded-xl` in standard utility mapping) for primary content cards, and balanced reductions for inner micro-components.

- **Entry Cards & Surfaces:** Exactly 12px (0.75rem). This curvature softens the layout while remaining geometric, crisp, and architectural.
- **Input Fields & Media Containers:** 12px (0.75rem), matching card geometry to maintain parallel border radii.
- **Buttons & Chips:** Micro-elements use a 6px to 8px radius to avoid visual ballooning, while pill shapes (`rounded-full`) are strictly reserved for ephemeral status dots and category metadata chips.
- **Image Embeds:** Always clipped to 12px radius with an inner or overlaying 1px hairline border (`rgba(15, 23, 42, 0.06)`) to prevent light-toned travel photos from bleeding into pure white card backgrounds.

## Components

### Buttons
- **Primary Action:** Solid `#0F172A` background, pure `#FFFFFF` text (`label-md`), 8px border radius, 0px border. Padding: 10px 18px. Active press state reduces opacity to `0.9` with no transform shift.
- **Secondary / Ghost:** Pure white `#FFFFFF` surface with a 1px `#E2E8F0` border, `#0F172A` text. Hover shifts border color to `#94A3B8`.
- **Icon Buttons:** 36x36px square with 8px radius; hairline border (`#E2E8F0`); icons render at 18px stroke with 1.5px stroke-width.

### Chips & Tags
- **Category Chips (Country, Transit, Mood):** 24px height, full pill radius (`9999px`), `#FFFFFF` background, 1px `#E2E8F0` border, `#0F172A` font (`label-sm`).
- **Active / Filtered Chips:** Deep charcoal background `#0F172A`, `#FFFFFF` font, 1px `#0F172A` border.
- **Location Tag:** Features a 6px neutral slate marker icon followed by geographic coordinates or place names styled with `meta-mono`.

### Cards (Journal Entries)
- **Structure:** Pure white `#FFFFFF` background, 12px rounded corners, 1px perimeter border in `#E2E8F0`. 
- **Internal Spacing:** 20px interior padding (`space-lg`).
- **Card Header:** Timestamp and location displayed on the upper line in `meta-mono` (`#64748B`), accompanied by a right-aligned single category chip.
- **Card Content:** Entry title in `headline-sm` (`#0F172A`), followed by 12px vertical spacing to the excerpt in `body-md` (`#334155`).
- **Footer:** Media strip (if photos exist) displaying thumbnails clipped with 8px radii, separated by 8px gaps.

### Lists
- Separated entirely by 1px hairline horizontal dividers (`#E2E8F0`). Zero background fills.
- List items feature 16px vertical padding (`space-md`). Secondary metadata items are right-aligned using `meta-mono`.

### Checkboxes & Radio Controls
- **Geometry:** 18x18px squares with 4px border radius (checkboxes) and 18x18px circles (radio buttons).
- **Default State:** 1.5px border in `#CBD5E1`, background transparent.
- **Checked State:** Solid `#0F172A` fill with a pure white 1.5px checkmark icon; no drop shadows.

### Input Fields
- Single-line and multiline fields use a `#FFFFFF` fill with a uniform 1px `#E2E8F0` border and 12px border radius.
- **Text:** 15px `Inter`, with placeholder copy rendered in `#94A3B8`.
- **Focus State:** Hairline border sharpens instantly to `#0F172A` (or `#3B82F6`); no outer glowing halo or shadow ring.

### Dedicated Component: The Daily Timeline Axis
- A vertical continuous 1px line (`#E2E8F0`) positioned along the left edge of the screen or card stream.
- Milestone nodes are represented by hollow 8px circles with 2px `#FFFFFF` center fills and 2px `#0F172A` rims. Active current-day nodes switch to a solid `#3B82F6` center.