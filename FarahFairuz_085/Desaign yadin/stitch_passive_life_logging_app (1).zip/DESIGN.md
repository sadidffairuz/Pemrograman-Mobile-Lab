---
name: Chronicle Kinetic
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#47464f'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#787680'
  outline-variant: '#c8c5d0'
  surface-tint: '#5b598c'
  primary: '#070235'
  on-primary: '#ffffff'
  primary-container: '#1e1b4b'
  on-primary-container: '#8683ba'
  inverse-primary: '#c4c1fb'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#140900'
  on-tertiary: '#ffffff'
  tertiary-container: '#331d00'
  on-tertiary-container: '#c07a00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e3dfff'
  primary-fixed-dim: '#c4c1fb'
  on-primary-fixed: '#181445'
  on-primary-fixed-variant: '#444173'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.006em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  mono-stat:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

The design system embodies calm precision, intentionality, and kinetic continuity. Serving as an automated life-logging and contextual movement companion, the interface balances dense telemetry data—such as timestamps, dwell durations, and coordinates—with serene, breathable visual spaces. The user experience evokes clarity, quiet reflection, and seamless trust.

The design language blends Modern Functional Minimalism with subtle Tactical Glassmorphism. Structural elements rely on clean slate canvases, crisp hairline dividers, soft diffuse ambient glows, and translucent floating dynamic sheets that give spatial context over active cartography and spatial logs.

## Colors

The palette is engineered around high functional specificity, distinguishing resting states from active movement and temporal duration:

- **Primary & Interactive Anchor (`#1E1B4B`, `#4338CA`)**: Deep Midnight Blue grounded by Indigo handles primary navigation, active waypoints, typography anchors, and critical interactive components.
- **Kinetic Accent (`#10B981`)**: Emerald Green denotes kinetic states: transit, movement detection, active GPS trails, step pulses, and live logging status.
- **Temporal Accent (`#F59E0B`)**: Warm Amber captures dwell moments: stationary pauses, cafe visits, workplace stays, and aggregated time metrics.
- **Neutral Canvas Foundations**:
  - Base canvas: `#F8FAFC` (Slate 50)
  - Surface cards & sheets: `#FFFFFF` with muted borders
  - Subtle fills & track wells: `#F1F5F9` (Slate 100)
  - Ghost dividers & hairline borders: `#E2E8F0` (Slate 200)
  - Body & metadata text: `#64748B` (Slate 500) and `#334155` (Slate 700)
  - High-emphasis text: `#0F172A` (Slate 900)

## Typography

The type system pairs **Plus Jakarta Sans** for expressive, warm geometric headings with **Inter** for neutral, utilitarian body copy and numerical readouts.

To maintain strict alignment across daily timelines, dwell timers, speed logs, and GPS coordinates, activate OpenType tabular figures (`tnum`) and slashed zeros (`zero`) across all numeric displays and `mono-stat` tokens. Running timestamps and timeline tick labels always utilize fixed-width numeric structures to prevent layout shifting during real-time GPS stream updates.

## Layout & Spacing

This design system uses a 4-column fluid mobile grid with 16px (`1rem`) outer margins and 16px (`1rem`) gutters, expanding to 8 columns on tablet viewports (min-width: 600px). 

Layout rhythm follows a strict 4px base increment. Vertical timelines anchor on an uninterrupted 2px track line inset 24px from the left edge, against which location nodes, transit segments, and stay cards align consistently.

Floating map overlays and control modules maintain safe bottom offsets of 34px on gesture-based mobile devices, clearing the home navigation indicator while preserving continuous cartographic context behind translucent backdrops.

## Elevation & Depth

Spatial layering relies on translucent surfaces and ambient, tinted shadows rather than opaque, high-contrast drop shadows:

- **Level 0 (Base Canvas)**: Solid `#F8FAFC`. Zero elevation.
- **Level 1 (Card & Content Blocks)**: Pure `#FFFFFF` resting on `#F8FAFC`, enclosed by a 1px border of `#E2E8F0`. Shadow: `0px 1px 3px rgba(15, 23, 42, 0.04), 0px 4px 12px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Floating Action Trays & Map Bottom Sheets)**: Background of `rgba(255, 255, 255, 0.88)` backed by `backdrop-filter: blur(16px)`, enclosed by `1px solid rgba(226, 232, 240, 0.8)`. Shadow: `0px 8px 24px -4px rgba(30, 27, 75, 0.08)`.
- **Level 3 (Modal Sheets & Context Menus)**: `#FFFFFF` with shadow `0px 16px 36px -6px rgba(15, 23, 42, 0.12)`.
- **Level 4 (Pill Badges & Live Status Overlays)**: Background of `rgba(255, 255, 255, 0.94)` with `backdrop-filter: blur(8px)`, framed by `1px solid rgba(255, 255, 255, 0.6)`. Shadow: `0px 2px 8px rgba(15, 23, 42, 0.06)`.

## Shapes

The interface embraces balanced, soft-cornered geometry (roundedness level 2):
- Standard interactive elements, content tiles, and card containers implement `0.75rem` to `1rem` (12px–16px) corner radii.
- Timeline node indicators, tracking pill indicators, filter chips, and map action bubbles employ full pill shapes (`9999px`).
- Modal sheets feature top-only radiused corners of `1.5rem` (24px).

## Components

### Buttons
- **Primary Kinetic Action**: Fill `#1E1B4B`, label `#FFFFFF`, border-radius `9999px` (pill), height `48px`, padding `0 24px`. Pressed state shifts to `#4338CA`.
- **Active Movement Button**: Fill `#10B981`, label `#FFFFFF`, displaying a pulsing outer ring for active tracking states.
- **Ghost & Map Float**: Translucent background `rgba(255, 255, 255, 0.92)`, border `1px solid #E2E8F0`, icon/text `#0F172A`, height `40px`, pill shape.

### Chips & Badges
- **Transit/Movement Pill**: Background `#ECFDF5`, text `#065F46`, border `1px solid #A7F3D0`. Includes a 6px solid `#10B981` dot prefix.
- **Dwell/Stay Duration Pill**: Background `#FFFBEB`, text `#92400E`, border `1px solid #FDE68A`. Tabular digits show elapsed time (e.g., `2h 15m`).
- **Filter Chips**: Height `32px`, border-radius `9999px`, default background `#F1F5F9` with text `#475569`; active state switches to background `#1E1B4B` with text `#FFFFFF`.

### Cards & Timeline Entries
- **Dwell Visit Card**: Solid `#FFFFFF` fill, 1px `#E2E8F0` border, `16px` inner padding, `16px` border-radius. Houses venue header, category tag, and warm amber dwell duration badge.
- **Transit Leg Card**: Minimal vertical connector with `#F1F5F9` nested strip, icon indicator (walking, driving, cycling) in `#10B981`, and tabular speed/distance stats.

### Inputs & Search Bars
- **Location Search**: Height `44px`, background `#FFFFFF`, border `1px solid #E2E8F0`, border-radius `12px`, placeholder `#94A3B8`. Left-anchored location pin icon in `#4338CA`. Active focus applies an outer glow: `0 0 0 3px rgba(67, 56, 202, 0.15)` with border color `#4338CA`.

### Selection Controls
- **Radio & Checkbox**: Rounded square (`6px` radius) for checkboxes, circular for radios. Inactive border `1.5px solid #CBD5E1`. Checked state uses `#1E1B4B` fill with a pure white check or inner dot.

### Specialized Telemetry Components
- **Timeline Rail**: Continuous 2px vertical stroke `#E2E8F0` running parallel to entries, housing dynamic 10px circular nodes colored `#10B981` (movement), `#F59E0B` (stay), or `#4338CA` (destination).
- **Floating Telemetry HUD**: Glassmorphic sheet docked at screen bottom with blur `16px`, displaying instantaneous speed, logging accuracy, and current geographic coordinates in tabular format.